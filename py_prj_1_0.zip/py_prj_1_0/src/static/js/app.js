//import { TaskService } from './TaskService.js';
//TaskService.init();
import { LogService } from './LogService.js';
LogService.test();
LogService.saveLog();





